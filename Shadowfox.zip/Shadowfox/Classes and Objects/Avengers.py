class Avenger:
    def __init__(self, name, age, gender, super_power, weapon):
        self.name = name
        self.age = age
        self.gender = gender
        self.super_power = super_power
        self.weapon = weapon
    
    def get_info(self):
        return f"""
        Name: {self.name}
        Age: {self.age}
        Gender: {self.gender}
        Super Power: {self.super_power}
        Weapon: {self.weapon}
        Leader: {'Yes' if self.is_leader() else 'No'}
        """
    
    def is_leader(self):
        return self.name == "Captain America"

super_heroes = [
    Avenger("Captain America", 105, "Male", "Super strength", "Shield"),
    Avenger("Iron Man", 48, "Male", "Technology", "Armor"),
    Avenger("Black Widow", 37, "Female", "Superhuman", "Batons"),
    Avenger("Hulk", 49, "Male", "Unlimited Strength", "No Weapon"),
    Avenger("Thor", 1500, "Male", "Super Energy", "Mjölnir"),
    Avenger("Hawkeye", 42, "Male", "Fighting skills", "Bow and Arrows")
]

for hero in super_heroes:
    print(hero.get_info())
    print("-" * 40)