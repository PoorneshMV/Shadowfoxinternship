# BERT NLP Analysis Notebook

# Install necessary libraries (uncomment if not already installed)
# !pip install transformers torch datasets matplotlib seaborn

from transformers import BertTokenizer, BertForMaskedLM, pipeline
import torch
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

# 1. Load Pretrained BERT Model and Tokenizer
model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertForMaskedLM.from_pretrained(model_name)

# 2. Setup Masked Language Pipeline
fill_mask = pipeline('fill-mask', model=model, tokenizer=tokenizer)

# 3. Example: Basic Masked Prediction
print("\n[INFO] Basic Masked Prediction")
example_1 = fill_mask("The capital of France is [MASK].")
for result in example_1:
    print(f"{result['token_str']} ({result['score']:.4f})")

# 4. Context Sensitivity Test
print("\n[INFO] Context Sensitivity Test")
example_2 = fill_mask("She played the [MASK] like a pro.")
for result in example_2:
    print(f"{result['token_str']} ({result['score']:.4f})")

# 5. Visualization Function
def visualize_predictions(predictions, title):
    tokens = [r['token_str'] for r in predictions]
    scores = [r['score'] for r in predictions]

    sns.set(style="whitegrid")
    plt.figure(figsize=(10, 6))
    sns.barplot(x=scores, y=tokens, palette="viridis")
    plt.xlabel("Confidence Score")
    plt.ylabel("Predicted Tokens")
    plt.title(title)
    plt.show()

print("\n[INFO] Visualizing Predictions")
visualize_predictions(example_2, "BERT Top Predictions: 'She played the [MASK] like a pro.'")

# 6. Define Research Questions (as markdown or printed summary)
research_questions = [
    "1. How accurate is BERT at predicting masked tokens in complex contexts?",
    "2. Can BERT understand idioms or ambiguous phrases?",
    "3. What are the limitations of BERT in non-standard English or sarcasm?",
    "4. How can BERT be improved for domain-specific tasks?"
]

print("\n[INFO] Research Questions")
for q in research_questions:
    print(q)

# 7. Conclusion Summary
conclusion = """
Conclusion:
BERT demonstrates a strong grasp of bidirectional context and performs well in predicting masked words. 
It excels in context-aware tasks but may require fine-tuning for domain-specific applications or creative language such as idioms or sarcasm.
Further improvements could be made through transfer learning or hybrid approaches with generative models.
"""
print("\n[INFO] Conclusion\n")
print(conclusion)

# 8. Timestamp
print(f"[INFO] Notebook completed on: {datetime.now().isoformat()}")