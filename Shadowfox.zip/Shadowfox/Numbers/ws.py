distance = 490
time = 7 * 60

speed = distance / time
print("Speed:", int(speed), "m/s")
