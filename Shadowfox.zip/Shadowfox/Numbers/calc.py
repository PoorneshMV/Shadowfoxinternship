radius = 84
pi = 3.14
water_per_sqm = 1.4

pond_area = pi * (radius ** 2)
print("Pond area:", pond_area, "square meters")

total_water = pond_area * water_per_sqm
print("Total water:", int(total_water), "liters")