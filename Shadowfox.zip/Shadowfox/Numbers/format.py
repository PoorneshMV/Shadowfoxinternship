def format_numbers(num, char):
    return "Formatted: {0:{1}}".format(num, char)

result = format_numbers(145, 'o')
print(result)