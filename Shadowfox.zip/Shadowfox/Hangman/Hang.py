import random

# Predefined list of words
WORDS = ['python', 'hangman', 'developer', 'challenge', 'algorithm', 'function', 'keyboard']

# Hangman visual stages
HANGMAN_PICS = [
    '''
      +---+
          |
          |
          |
         ===''', '''
      +---+
      O   |
          |
          |
         ===''', '''
      +---+
      O   |
      |   |
          |
         ===''', '''
      +---+
      O   |
     /|   |
          |
         ===''', '''
      +---+
      O   |
     /|\\  |
          |
         ===''', '''
      +---+
      O   |
     /|\\  |
     /    |
         ===''', '''
      +---+
      O   |
     /|\\  |
     / \\  |
         ==='''
]

MAX_ATTEMPTS = len(HANGMAN_PICS) - 1

def get_random_word():
    return random.choice(WORDS)

def display_game_state(word, guessed_letters, incorrect_guesses):
    print(HANGMAN_PICS[incorrect_guesses])
    print("\nWord: ", ' '.join([letter if letter in guessed_letters else '_' for letter in word]))
    print("Guessed letters: ", ' '.join(sorted(guessed_letters)))
    print(f"Incorrect guesses: {incorrect_guesses}/{MAX_ATTEMPTS}")

def play_game():
    word = get_random_word()
    guessed_letters = set()
    incorrect_guesses = 0

    while True:
        display_game_state(word, guessed_letters, incorrect_guesses)

        guess = input("Guess a letter: ").lower()
        if not guess.isalpha() or len(guess) != 1:
            print("Please enter a valid single letter.")
            continue

        if guess in guessed_letters:
            print("You've already guessed that letter.")
            continue

        guessed_letters.add(guess)

        if guess not in word:
            incorrect_guesses += 1
            print("Incorrect guess!")

        if all(letter in guessed_letters for letter in word):
            display_game_state(word, guessed_letters, incorrect_guesses)
            print(f"🎉 Congratulations! You guessed the word '{word}'. You win!")
            break

        if incorrect_guesses >= MAX_ATTEMPTS:
            display_game_state(word, guessed_letters, incorrect_guesses)
            print(f"💀 Game over! The word was '{word}'.")
            break

def main():
    while True:
        play_game()
        again = input("\nWould you like to play again? (y/n): ").lower()
        if again != 'y':
            print("Thanks for playing Hangman! Goodbye!")
            break

if __name__ == "__main__":
    main()