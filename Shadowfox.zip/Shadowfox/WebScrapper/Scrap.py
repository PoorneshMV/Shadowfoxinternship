import undetected_chromedriver as uc
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
from datetime import datetime

URL = "https://shadowfox.in/"
OUTPUT_FILE = "internships.json"

def get_rendered_html():
    options = uc.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--window-size=1920,1080")

    driver = uc.Chrome(options=options)

    print("[INFO] Opening the website...")
    driver.get(URL)

    try:
        # Wait up to 15 seconds for at least one internship card to load
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CLASS_NAME, "service-col"))
        )
        print("[INFO] Internship content loaded.")
    except Exception as e:
        print(f"[ERROR] Timeout waiting for internships: {e}")
    
    html = driver.page_source
    driver.quit()
    return html

def parse_internships(html):
    soup = BeautifulSoup(html, "html.parser")
    internships = []

    for item in soup.select("div.service-col"):
        title = item.find("h3").get_text(strip=True)
        description = item.find("p").get_text(strip=True)
        image_tag = item.find("img")
        image = image_tag["src"] if image_tag else ""
        apply_link = item.find("a", class_="apply-button")["href"]

        internships.append({
            "title": title,
            "description": description,
            "image": URL + image if image.startswith("/") else image,
            "apply_link": apply_link
        })

    return internships

def save_json(data):
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "timestamp": datetime.utcnow().isoformat(),
            "internships": data
        }, f, ensure_ascii=False, indent=2)
    print(f"[INFO] Saved {len(data)} internships to {OUTPUT_FILE}")

def main():
    html = get_rendered_html()
    internships = parse_internships(html)
    if internships:
        save_json(internships)
    else:
        print("[WARNING] No internships found.")

if __name__ == "__main__":
    main()