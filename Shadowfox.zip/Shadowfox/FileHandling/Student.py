import csv

file_path = '/Users/poorneshmv/Downloads/student_marks.csv'
output_path = '/Users/poorneshmv/Downloads/student_marks_with_results.csv'

try:
    # First pass to clean fieldnames
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        headers = next(reader)
        clean_headers = [h.strip() for h in headers if h.strip()]

    # Second pass to process data
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file, fieldnames=clean_headers)
        next(reader)  # Skip header row
        students = []
        
        for row in reader:
            if not any(row.values()):  # Skip empty rows
                continue
            
            # Clean the student record
            student = {k: v.strip() for k, v in row.items() if k in clean_headers}
            
            # Calculate marks
            subject_columns = [col for col in clean_headers if col.lower() != 'name']
            total = 0
            valid_subjects = 0
            
            for subject in subject_columns:
                try:
                    mark = int(student.get(subject, '0') or 0)
                    total += mark
                    valid_subjects += 1
                except (ValueError, TypeError):
                    continue
            
            student['Total_Marks'] = str(total)
            student['Average'] = str(round(total/valid_subjects, 2)) if valid_subjects else '0'
            students.append(student)
    
    # Write output
    output_fields = clean_headers + ['Total_Marks', 'Average']
    with open(output_path, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=output_fields)
        writer.writeheader()
        writer.writerows(students)
    
    print(f"Successfully processed {len(students)} records")
    print(f"Results saved to {output_path}")

except FileNotFoundError:
    print(f"Error: File not found at {file_path}")
except Exception as e:
    print(f"Processing error: {str(e)}")