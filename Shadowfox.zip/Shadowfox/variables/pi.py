pi = 22/7
print(pi) 
print(type(pi))  