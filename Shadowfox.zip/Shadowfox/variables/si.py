
principal = 1000  
rate = 5        
time = 3        


simple_interest = (principal * rate * time) / 100

print("Simple Interest:", simple_interest) 